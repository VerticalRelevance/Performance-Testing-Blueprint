#!/bin/sh

set -eu

mkdir -p /working/proxies

cp -r /consumer/proxies /working
